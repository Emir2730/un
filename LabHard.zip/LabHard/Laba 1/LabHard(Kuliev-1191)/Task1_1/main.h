#include "stm32f0xx.h"		//Заголовок устройства  
void delay(uint32_t);			//Декларация функции задержки
