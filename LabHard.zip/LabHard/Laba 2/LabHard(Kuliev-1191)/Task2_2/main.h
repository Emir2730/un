#include "stm32f0xx.h" //Подключение библиотеки с моделью stm32f0xx
void InitUSART1(void); //Декларация функции инициализации USART1
void msg(uint8_t, unsigned); //Декларация функции передачи данных
