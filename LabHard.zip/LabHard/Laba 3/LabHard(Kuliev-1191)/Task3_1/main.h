#include "stm32f0xx.h" 								//Заголовок устройства  
void InitUSART1(void); 								//Декларация функции инициализации USART1
void USART1_IRQHandler(void); 				//Декларация функции обработки прерывания от USART1
void delay(uint32_t);									//Декларация Функции задержки
